/* main blink program */
#include <stdio.h>
#include <string.h>
#include "esp_log.h"
#include "esp_console.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "blink.h"

static const char *TAG = "blink";
static int uart_cmd(int argc, char **argv);

extern "C" void app_main(void) {

    ESP_LOGI(TAG,"firmware started");

    //   ---------------- CONSOLE ----------------
    esp_console_repl_t *repl = NULL;
    esp_console_repl_config_t repl_config = ESP_CONSOLE_REPL_CONFIG_DEFAULT();
    esp_console_dev_uart_config_t uart_config = ESP_CONSOLE_DEV_UART_CONFIG_DEFAULT();
    
    repl_config.prompt = "esp32 >"; // Prompt to be printed before each line, this can be customized, made dynamic, etc.
    repl_config.max_cmdline_length = CONFIG_CONSOLE_MAX_COMMAND_LINE_LENGTH;

    esp_console_register_help_command(); // Register commands

    const esp_console_cmd_t cmd_version = {
        .command = "version",
        .help = "version",
        .hint = "shows the current (esp32) software (firmware) version",
        .func = &uart_cmd,
    };
    ESP_ERROR_CHECK(esp_console_cmd_register(&cmd_version));
    ESP_ERROR_CHECK(esp_console_new_repl_uart(&uart_config, &repl_config, &repl));
    ESP_ERROR_CHECK(esp_console_start_repl(repl));

    //   --------------- BLINK LED ---------------
    gpio_set_direction((gpio_num_t) RED_LED_GPIO, GPIO_MODE_OUTPUT);
    ESP_LOGI(TAG, "red led gpio initialized.");

    //   ----------------- LOOP ------------------
    while(1) {
        gpio_set_level((gpio_num_t) RED_LED_GPIO, HIGH);
        vTaskDelay(1000 / portTICK_PERIOD_MS); // sleep for 1 seconds
        gpio_set_level((gpio_num_t) RED_LED_GPIO, LOW);
        vTaskDelay(1000 / portTICK_PERIOD_MS); // sleep for 1 seconds
        ESP_LOGI(TAG,"one cycle done");
    }
}

/* UART commands */
static int uart_cmd(int argc, char **argv) {

  if(strcmp(argv[0],"version") == 0) {
      ESP_LOGI(TAG,"firmware version: %s",SOFTWARE_VERSION);
  }
  return 0;
}
